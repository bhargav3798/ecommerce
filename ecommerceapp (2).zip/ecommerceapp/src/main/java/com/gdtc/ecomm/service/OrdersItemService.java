package com.gdtc.ecomm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdtc.ecomm.repository.OrdersItemRepository;



@Service
public class OrdersItemService {
	
	@Autowired
	private OrdersItemRepository ordRepo;
	

}
