package com.gdtc.ecomm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdtc.ecomm.model.Cart;
import com.gdtc.ecomm.model.CartItem;
import com.gdtc.ecomm.model.Product;
import com.gdtc.ecomm.repository.CartItemRepository;




@Service
public class CartItemService 
{
	
	
		@Autowired
		private CartItemRepository cartrep;
		
		@Autowired
		private ProductService prodSer;
		
		@Autowired
		private CartService cartser;
		
		public List<CartItem> getAllCartItem() {
			return cartrep.findAll();
		}
		
		public CartItem saveItem(CartItem item) {
			return cartrep.save(item);
		}
		
		public CartItem getById(int id) {
			return cartrep.findById(id);
		}
		
		
		
		public CartItem addToCart(int id,int pid) 
		{
			Product p=prodSer.getById(pid);
			CartItem c=new CartItem();
			
			if(findCartItemBypid(pid, id)!=null) 
			{
				
					c=findCartItemBypid(pid, id);
					c.setQty(c.getQty()+1);
					update(c, c.getId());
				
			}else 
			{
				
				c.setProductName(p.getProductName());
				c.setCategory(p.getCategory());
				c.setDescription(p.getDescription());
				c.setImageURL(p.getImageURL());
				c.setProductCode(p.getProductCode());
				c.setReleaseDate(p.getReleaseDate());
				c.setStarRating(p.getStarRating());
				c.setPrice(p.getPrice());
				c.setProduct(p);
				c.setQty(1);
				saveItem(c);
			}
			 
			
			Cart cart=cartser.findCart(id);
			
			List<CartItem> list=new ArrayList<>();
			if(cart.getCartItems()!=null) {
				 list=cart.getCartItems();
				 list.add(c);
				 cart.setCartItems(list);
			}
			
			else {
				list.add(c);
				cart.setCartItems(list);
			}
			
			Cart res=cartser.updateCart(cart, id);
			boolean check=false;
			if(res!=null) 
			{
				check=true;
			}
			
			return check?c:null;
		}
		
		
		
		
		public CartItem findCartItemBypid(int pid,int cid) 
		{
			return cartrep.findCartItem(pid, cid);
		}
		
		
		
		
		
		public CartItem update(CartItem item,int cid) 
		{
			CartItem c=getById(cid);
			c.setId(cid);
			c.setPrice(item.getPrice());
			c.setProduct(item.getProduct());
			c.setQty(item.getQty());
			
			return cartrep.save(c);
			
		}
		
		public CartItem incCartItems( int id) {
			// TODO Auto-generated method stub
			CartItem c=getById(id);
			
			if(c.getQty()>0) {
				c.setQty(c.getQty()+1);
			}
			return cartrep.save(c);
		}
		
		public CartItem decCartItems(int id) {
			CartItem c = getById(id);
			
			if(c.getQty()>1) {
				c.setQty(c.getQty()-1);
			}
			return cartrep.save(c);
		}
		
		
		public CartItem removeCartItem(int pid,int id) 
		{
			Cart c= cartser.findCart(id);
			Product p=prodSer.getById(id);
			List<CartItem> list=new ArrayList<>();
			if(c.getCartItems()!=null) 
			{
				list=c.getCartItems();
				CartItem item=findCartItemBypid(pid, id);
				list.remove(item);
				c.setCartItems(list);
				cartser.updateCart(c, id);
				return item;
			}
			
			else {
				return null;
			}
		}
		
		public CartItem removeAll() {
			return null;
		}
		
}
