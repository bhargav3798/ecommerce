package com.gdtc.ecomm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdtc.ecomm.model.CartItem;
import com.gdtc.ecomm.model.Orders;
import com.gdtc.ecomm.model.OrdersItem;
import com.gdtc.ecomm.model.User;
import com.gdtc.ecomm.repository.OrdersRepository;

@Service
public class OrdersService {
	
	@Autowired
	private OrdersRepository ordRepo;
	
	@Autowired
	private UserService userSer;
	
	public Orders placeOrder(int id) {
		
		User u = userSer.getUserById(id);
		Orders order = new Orders();
		
		List<OrdersItem> list = new ArrayList();
		List<CartItem> itemList = u.getCart().getCartItems();
		
		if(u.getCart().getCartItems() !=null) {
			
			for(CartItem c:itemList) {
				OrdersItem ord = new OrdersItem();
				ord.setPrice(c.getPrice());
				ord.setProductName(c.getProductName());
				ord.setQty(c.getQty());
				ord.setCartItem(c);
				list.add(ord);
			}
			
			List<Orders> userlist = u.getOrders();
			if(userlist == null) {
			    userlist = new ArrayList<Orders>();
			}
			
			userlist.add(order);
			order.setOrderItem(list);
			Orders ord= ordRepo.save(order);
			u.getCart().setCartItems(null);
			u.setOrders(userlist);
			userSer.updateUser(u, id);
			
			if(ord!=null) {
				return order;
			}
			else {
				return null;
			}
		}
		else {
			return null;
		}
		
	}
	
	public List<Orders> getAllOrders(){
		return ordRepo.findAll();
	}

}
