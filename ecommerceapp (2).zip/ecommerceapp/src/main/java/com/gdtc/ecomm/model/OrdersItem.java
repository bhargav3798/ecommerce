package com.gdtc.ecomm.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class OrdersItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id ;
	
	private String productName;
	private int qty;
	private int price;
	
	
	@OneToOne()
	private CartItem cartItem;

	public OrdersItem(String productName, int qty, int price, CartItem cartItem) {
		super();
		this.productName = productName;
		this.qty = qty;
		this.price = price;
		this.cartItem = cartItem;
	}

	public OrdersItem() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public CartItem getCartItem() {
		return cartItem;
	}

	public void setCartItem(CartItem cartItem) {
		this.cartItem = cartItem;
	}

	@Override
	public String toString() {
		return "OrdersItem [id=" + id + ", productName=" + productName + ", qty=" + qty + ", price=" + price
				+ ", cartItem=" + cartItem + "]";
	}
	
	
}
