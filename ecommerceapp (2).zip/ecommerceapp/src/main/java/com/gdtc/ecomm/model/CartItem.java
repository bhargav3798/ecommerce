package com.gdtc.ecomm.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;

@Entity
public class CartItem {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String productName;
	private String productCode;
	private String releaseDate;
	private String description;
	private int price;
	private Double starRating;
	@Lob
	@Column(length = 214753298)
	private byte[] imageURL;
	private String category;
	private int qty;
	
	
	
	public CartItem(String productName, String productCode, String releaseDate, String description, int price,
			Double starRating, byte[] imageURL, String category, int qty, Product product) {
		super();
		this.productName = productName;
		this.productCode = productCode;
		this.releaseDate = releaseDate;
		this.description = description;
		this.price = price;
		this.starRating = starRating;
		this.imageURL = imageURL;
		this.category = category;
		this.qty = qty;
		this.product = product;
	}

	public CartItem() {
		// TODO Auto-generated constructor stub
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@OneToOne()
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	private Product product;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getStarRating() {
		return starRating;
	}

	public void setStarRating(Double starRating) {
		this.starRating = starRating;
	}

	public byte[] getImageURL() {
		return imageURL;
	}

	public void setImageURL(byte[] imageURL) {
		this.imageURL = imageURL;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "CartItem [id=" + id + ", productName=" + productName + ", productCode=" + productCode + ", releaseDate="
				+ releaseDate + ", description=" + description + ", price=" + price + ", starRating=" + starRating
				+ ", imageURL=" + imageURL + ", category=" + category + ", qty=" + qty + ", product=" + product + "]";
	}

	

	
	
	
}
