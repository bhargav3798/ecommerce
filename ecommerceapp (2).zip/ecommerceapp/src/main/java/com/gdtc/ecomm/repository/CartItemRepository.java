package com.gdtc.ecomm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.gdtc.ecomm.model.CartItem;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Integer> {

	
	CartItem findById(int id);
	boolean existsByProductName(String name);
	
	@Query(value = "select c.* from cart_item c join product p on p.id=c.product_id join cart c1 on c1.id=c.cart where p.id=?1 and c1.id=?2",nativeQuery = true)
	CartItem findCartItem( int pid,int cid);
}
