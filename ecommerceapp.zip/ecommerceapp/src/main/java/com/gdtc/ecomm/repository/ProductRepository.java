package com.gdtc.ecomm.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gdtc.ecomm.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	boolean existsById(long id);
	
	Product findById(int id);
	

    @Query("SELECT p FROM Product p WHERE p.productName = :productName")
    public Product findByproductName(@Param("productName") String productName);

	List<Product> findAll(Specification<Product> spec);

}
