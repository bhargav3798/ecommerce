package com.gdtc.ecomm.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gdtc.ecomm.model.Product;
import com.gdtc.ecomm.repository.ProductRepository;
import com.gdtc.ecomm.service.ProductService;

@RestController
@RequestMapping(value = "/api/product")
public class ProductController 
{
	
	@Autowired
	private ProductService ser;
	
	@Autowired
	private ProductRepository prodRepo;
	
	@GetMapping(value = "/all")
	public List<Product> getAllProduct() {
		return ser.getAllProduct();
	}
	
	@PostMapping(value = "/add")
	public Product addProduct(@RequestBody Product p) 
	{
		return ser.addProduct(p);
	}
	@GetMapping(value = "get/{id}")
	public Product getById(@PathVariable("id") int id)
	{
		return ser.getById(id);
	}

   	@PutMapping(value = "/update/{id}")
	public Product updateProduct(@PathVariable int id, @RequestBody Product productData){
   		return ser.updateProduct(productData, id);
	}
   	
   	@DeleteMapping(value = "delete/{id}")
   	public long deleteProduct(@PathVariable int id) {
   		return ser.deleteProduct(id);
   	}
   	
	@PostMapping(value = "/upload/{id}")
	public Product uplaodImage(@RequestParam MultipartFile file ,@PathVariable int id ) throws IOException {
        return ser.uplaodImage(file, id) ;
	}



	  @GetMapping("/predicates")
	  public List<Product> createPredicate(@RequestParam(required = false) String productName,
	                                     @RequestParam(required = false) String productCode,
	                                     @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate releaseDate
	                                    ) {
	      Specification<Product> spec = (root, query, builder) -> ser.createPredicate(productName, productCode, releaseDate, root, builder);
	        return prodRepo.findAll(spec);
	  }
	
	  
//		@GetMapping(value = "/get/{productName}" )
//		public Product getImage(@PathVariable("productName") String productName){
	//
//			return ser.getImage(productName) ;
//		}

	
}
