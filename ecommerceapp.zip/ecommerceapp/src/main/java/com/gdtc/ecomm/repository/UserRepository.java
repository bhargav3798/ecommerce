package com.gdtc.ecomm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gdtc.ecomm.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{

	User findByEmailId(String emailId);
	   User findByPassword(String password);
}
