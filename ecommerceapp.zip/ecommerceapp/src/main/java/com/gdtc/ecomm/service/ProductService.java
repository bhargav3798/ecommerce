package com.gdtc.ecomm.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gdtc.ecomm.model.Product;
import com.gdtc.ecomm.repository.ProductRepository;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;



@Service
public class ProductService {

	@Autowired
	private ProductRepository rep;

	public List<Product> getAllProduct() {
		return rep.findAll();
	}
	
	public Product addProduct(Product p) {
		return rep.save(p);
	}
	
	public Product getById( int id)
	{
		return rep.findById(id);
	}

	public Product updateProduct(Product productData, int id) {
		// TODO Auto-generated method stub
		Product product=rep.findById(id);
				
		
		product.setProductName(productData.getProductName());
		product.setProductCode(productData.getProductCode());
		product.setDescription(productData.getDescription());
		product.setPrice(productData.getPrice());
		product.setReleaseDate(productData.getReleaseDate());
		product.setStarRating(productData.getStarRating());
		product.setImageURL(productData.getImageURL());
		product.setId(productData.getId());
		product.setCategory(productData.getCategory());
		product.setQty(productData.getQty());
		
		Product products =rep.save(product);
		return products;
	}
	
	
	public int deleteProduct(int id) {
	
		 if(rep.existsById(id)) 
		 {
			 rep.deleteById(id);
			 return id;
		 }
		 else
		 {
			 return 0;
		 }
	}
	
	public Product uplaodImage(MultipartFile file , int id ) throws IOException {
		
	    Product product = rep.findById(id);
	    product.setImageURL((file.getBytes()));
	
		
		return rep.save(product);
	}

	
	public Predicate createPredicate(String productName, String productCode, LocalDate releaseDate, Root<Product> root, CriteriaBuilder builder) {
	    Predicate predicate = builder.conjunction();
	    if (productName != null && !productName.isEmpty()) {
	        predicate = builder.and(predicate, builder.like(builder.lower(root.get("productName")), "%" + productName.toLowerCase() + "%"));
	    }
	    if (productCode != null && !productCode.isEmpty()) {
	        predicate = builder.and(predicate, builder.like(builder.lower(root.get("productCode")), "%" + productCode.toLowerCase() + "%"));
	    }
	    if (releaseDate != null) {
	        predicate = builder.and(predicate, builder.equal(root.get("releaseDate"), releaseDate));
	    }
//	    if (price > 0 )  {
//	        predicate = builder.and(predicate, builder.greaterThanOrEqualTo(root.get("price"), price));
//	    }
	    return predicate;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// compress the image bytes before storing it in the database
	/*
	 * public static byte[] compressBytes(byte[] data) { Deflater deflater = new
	 * Deflater(); deflater.setInput(data); deflater.finish();
	 * 
	 * ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
	 * byte[] buffer = new byte[1024]; while (!deflater.finished()) { int count =
	 * deflater.deflate(buffer); outputStream.write(buffer, 0, count); } try {
	 * outputStream.close(); } catch (IOException e) { }
	 * System.out.println("Compressed Image Byte Size - " +
	 * outputStream.toByteArray().length);
	 * 
	 * return outputStream.toByteArray(); }
	 * 
	 * // uncompress the image bytes before returning it to the angular application
	 * public static byte[] decompressBytes(byte[] data) { Inflater inflater = new
	 * Inflater(); inflater.setInput(data); ByteArrayOutputStream outputStream = new
	 * ByteArrayOutputStream(data.length); byte[] buffer = new byte[1024]; try {
	 * while (!inflater.finished()) { int count = inflater.inflate(buffer);
	 * outputStream.write(buffer, 0, count); } outputStream.close(); } catch
	 * (IOException ioe) { } catch (DataFormatException e) { } return
	 * outputStream.toByteArray(); }
	 */
}

