package com.gdtc.ecomm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdtc.ecomm.model.Cart;
import com.gdtc.ecomm.model.CartItem;
import com.gdtc.ecomm.repository.CartRepository;



@Service
public class CartService {

	@Autowired
	private CartRepository cartrep;
	
	public Cart addCart(Cart c) {
		return cartrep.save(c);
	}
	
	public Cart findCart(int id) {
		return cartrep.findById(id).get();
	}
	
	public Cart updateCart(Cart c ,int id) 
	{
		Cart cart=findCart(id);
		cart.setCartItems(c.getCartItems());
		
		return cartrep.save(cart);
	}
	
	public Cart removeFromCart(int id, int cid) {
		// TODO Auto-generated method stub
       Cart cart = this.findCart(id);
        
        CartItem itemToRemove = null;
        List<CartItem> temp = cart.getCartItems();
        for (CartItem item : temp) {
            if (item.getId()==(cid)) {
                itemToRemove = item;
                break;
            }
        }
        cart.getCartItems().remove(itemToRemove);
        
 
        cartrep.save(cart);
        return cart;
		
	}
	
	public Optional<Cart> removeAllCartProduct(int id) {
		// TODO Auto-generated method stub
		
		Optional<Cart> c = cartrep.findById(id);
		        if (c.isPresent()) {
		            Cart cart = c.get();
		            cart.getCartItems().clear();
		            cartrep.save(cart);
		        }
	        return c;
	}
}
