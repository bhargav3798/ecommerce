package com.gdtc.ecomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gdtc.ecomm.model.User;
import com.gdtc.ecomm.service.UserService;

@RestController
@RequestMapping("/api/user/")
public class UserController {

	@Autowired
	private  UserService userSer; 
	
	@GetMapping("/all")
	public List<User> getAllUSer() {
		return userSer.getAllUser();
	}
	
	@GetMapping("/{id}")
	public User getUserById(@PathVariable ("id") Integer id) {
		return userSer.getUserById(id);
	}
	
	@PostMapping("/add")
	public User addUser(@RequestBody User user) {
		return userSer.addUser(user);
	}
	
	@PostMapping("/authenticateUser")
	public String authenticateUsers(@RequestBody User user) {
		return userSer.authenticateUser(user);
	}
	
	 @GetMapping("/findByEmail/{emailId}")
	    public User getByEmailId(@PathVariable("emailId") String emailId) {
	    	return userSer.getByEmailId(emailId);
	    }
	    
	    @GetMapping("/find/{password}")
	    public User getByPassword(@PathVariable String password) {
	    	return userSer.getByPassword(password);
	    }
	
	
	
}
