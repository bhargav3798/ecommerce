package com.gdtc.ecomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gdtc.ecomm.model.Cart;
import com.gdtc.ecomm.model.CartItem;
import com.gdtc.ecomm.service.CartItemService;

@RestController
@RequestMapping(value = "/cartItem")
public class CartItemController 
{
	@Autowired
	private CartItemService itemser;
	
	@GetMapping(value="/all")
	public List<CartItem> getAllCartItem(){
		return itemser.getAllCartItem();
	}
	
	@PostMapping(value = "/add")
	public CartItem addCartItem(@RequestBody CartItem c) 
	{
		return itemser.saveItem(c);
	}
	
	@GetMapping(value = "/get/{id}")
	public CartItem getById(@PathVariable("id") int id) {
		return itemser.getById(id);
	}
	
	@PutMapping(value = "/update/{cid}")
	public CartItem updateCartItem(@RequestBody CartItem item,@PathVariable int cid) {
		return itemser.update(item, cid);
	}
	
	@PutMapping(value = "/inc/{id}")
	public CartItem incCartItem(@PathVariable int id) {
		return itemser.incCartItems(id);
	}
	
	@PutMapping(value= "/dec/{id}")
	public CartItem decCartItem(@PathVariable int id) {
		return itemser.decCartItems(id);
	}
	
	@GetMapping(value = "/addtocart/{id}/{pid}")
	public CartItem addTocart(@PathVariable("id") int id,@PathVariable("pid") int pid) 
	{
		return itemser.addToCart(id, pid);
	}
	
	@GetMapping(value = "/getBypid/{pid}/{cid}")
	public CartItem getBYproductId(@PathVariable("pid") int pid,@PathVariable("cid") int cid) 
	{
		return itemser.findCartItemBypid(pid,cid);
	}
	
	@DeleteMapping(value = "/removecartitem/{pid}/{id}")
	public CartItem removeFromCart(@PathVariable("pid") int pid,@PathVariable("id") int id)
	{
		return itemser.removeCartItem(pid, id);
	}
	
}
