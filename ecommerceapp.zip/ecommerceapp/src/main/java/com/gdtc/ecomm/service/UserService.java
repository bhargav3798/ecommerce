package com.gdtc.ecomm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.gdtc.ecomm.model.User;
import com.gdtc.ecomm.repository.UserRepository;

@Service
public class UserService {
	
    @Autowired
	private UserRepository userRepo;
    
    public List<User> getAllUser() {
    	return userRepo.findAll();
    }
    
    public User getUserById(Integer id) {
    	return userRepo.findById(id).get();
    }
    
    public User addUser(User user) {
    	
    	BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
    	 String encryptedPwd = bcrypt.encode(user.getPassword());
    	 user.setPassword(encryptedPwd);
    	return userRepo.save(user);
    }
	
    public String authenticateUser(User user) {
    	
    	BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
   	Optional<User> userOpt = userRepo.findById(user.getId());
   	
   	//if(userOpt.isPresent()){
   		
   		User userDB = userOpt.get();
   		if(bcrypt.matches(user.getPassword(), userDB.getPassword()))
   		//if(user.getPassword().equals(userDB.getPassword())) 
   			return "authenticated user";
   		
   		else 
   			return "Incorrect password";
   	
      
	
    }
    
	public User getByEmailId(String emailId) {
		// TODO Auto-generated method stub
		return userRepo.findByEmailId(emailId);
		
	}

	
	public User getByPassword(String password) {
		// TODO Auto-generated method stub
		return userRepo.findByPassword(password);
	}
	
	public User updateUser(User user, int id) {
		
		User u = getUserById(id);
		u.setId(user.getId());
		u.setCart(user.getCart());
		u.setEmailId(user.getEmailId());
		u.setName(user.getName());
		u.setPassword(user.getPassword());
		u.setOrders(user.getOrders());
		return userRepo.save(user);
		
	}

	

}
